<?php
// Prevent direct access to letters folder
header('Location: ../../residential_lease_open.php');
exit;

